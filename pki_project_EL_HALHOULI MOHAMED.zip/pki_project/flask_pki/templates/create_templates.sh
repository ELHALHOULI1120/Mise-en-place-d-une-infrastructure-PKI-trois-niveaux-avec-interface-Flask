#!/bin/bash

# Liste des fichiers avec leurs titres
declare -A files=(
  ["generate_csr.html"]="Générer une CSR"
  ["view_certificates.html"]="Voir mes certificats"
  ["pending_csrs.html"]="CSR en attente"
  ["sign_delete_csr.html"]="Signer ou supprimer une CSR"
  ["revoked_signed_certs.html"]="Certificats signés / révoqués"
  ["revoke_cert.html"]="Révoquer un certificat"
  ["login.html"]="Connexion"
)

# Créer les fichiers avec le contenu HTML de base
for filename in "${!files[@]}"; do
  title="${files[$filename]}"
  cat > "$filename" <<EOF
{% extends 'base.html' %}

{% block title %}$title{% endblock %}

{% block content %}
    <h2>$title</h2>
    <p>Contenu à venir...</p>
{% endblock %}
EOF
  echo "Fichier $filename créé avec succès."
done
