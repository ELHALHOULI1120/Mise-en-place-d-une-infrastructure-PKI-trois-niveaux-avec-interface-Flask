from flask import Flask, render_template, request, redirect, url_for, session, g, flash, send_from_directory
import os
import subprocess
from pki_logic.openssl_wrapper import sign_csr
from pki_logic import openssl_wrapper
from flask import abort



app = Flask(__name__)
app.secret_key = 'pki_secret'  # À sécuriser en production



@app.before_request
def load_user():
    g.current_user = session.get('user')




# Dossiers nécessaires
os.makedirs("csrs", exist_ok=True)
os.makedirs("certs", exist_ok=True)
os.makedirs("revoked", exist_ok=True)





@app.route('/')
def index():
    if not g.current_user:
        return redirect(url_for('login'))
    return render_template("index.html", user=g.current_user)



@app.route('/generate-csr', methods=['GET', 'POST'])
def generate_csr():
    user = g.current_user
    if not user or user['role'] != 'client':
        return redirect(url_for('login'))

    if request.method == 'POST':
        cn = request.form['common_name']
        o = request.form['organization']
        ou = request.form['org_unit']
        c = request.form['country']
        email = request.form['email']

        csr_filename = f"csrs/{cn.replace(' ', '_')}.csr"
        key_filename = f"csrs/{cn.replace(' ', '_')}.key"

        subprocess.run([
            "openssl", "req", "-new",
            "-newkey", "rsa:2048", "-nodes",
            "-keyout", key_filename,
            "-out", csr_filename,
            "-subj", f"/C={c}/O={o}/OU={ou}/CN={cn}/emailAddress={email}"
        ])

        return render_template("generate_csr.html", user=user, message="CSR générée avec succès.")
    
    return render_template("generate_csr.html", user=user)




@app.route('/view-certificates')
def view_certificates():
    user = g.current_user
    if not user or user['role'] != 'client':
        return redirect(url_for('login'))

    certs_dir = 'certs'
    revoked_dir = 'revoked'

    all_files = os.listdir(certs_dir)
    revoked_files = os.listdir(revoked_dir) if os.path.exists(revoked_dir) else []

    user_certs = []
    for f in all_files:
        if user['id'] in f:
            is_revoked = f in revoked_files  # compare par nom pur
            user_certs.append({
                'name': f,
                'revoked': is_revoked
            })

    return render_template('view_certificates.html', user=user, certs=user_certs)




@app.route('/certs/<path:filename>')
def download_cert(filename):
    # Empêche le téléchargement si le fichier est aussi présent dans revoked/
    if os.path.exists(os.path.join('revoked', filename)):
        abort(403, description="Téléchargement interdit : certificat révoqué.")

    return send_from_directory('certs', filename, as_attachment=False)




@app.route('/download/<filename>')
def download_cert_(filename):
    user = g.current_user
    if not user or user['role'] != 'client':
        return redirect(url_for('login'))

    certs_dir = os.path.join(os.getcwd(), 'certs')
    
    # Sécurité : autoriser uniquement les fichiers appartenant à l'utilisateur
    if user['id'] not in filename:
        return "Accès refusé", 403

    return send_from_directory(certs_dir, filename, as_attachment=True)




from datetime import datetime




from datetime import datetime






@app.route('/pending-csrs', methods=['GET'])
def pending_csrs():
    user = g.current_user
    if not user or user['role'] != 'ca':
        return redirect(url_for('login'))

    csr_dir = 'csrs'
    csr_files = []
    for filename in os.listdir(csr_dir):
        if filename.endswith('.csr'):
            path = os.path.join(csr_dir, filename)
            timestamp = datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M:%S')
            csr_files.append({'name': filename, 'timestamp': timestamp})

    return render_template('pending_csrs.html', csrs=csr_files, user=user)






@app.route('/manage-csrs', methods=['GET', 'POST'])
def manage_csrs():
    user = g.current_user
    if not user or user['role'] != 'ca':
        return redirect(url_for('login'))

    csr_dir = 'csrs'
    message = None

    csr_files = []
    for filename in os.listdir(csr_dir):
        if filename.endswith('.csr'):
            path = os.path.join(csr_dir, filename)
            timestamp = datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M:%S')
            csr_files.append({'name': filename, 'timestamp': timestamp})

    if request.method == 'POST':
        csr_name = request.form['csr_name']
        action = request.form['action']
        csr_path = os.path.join(csr_dir, csr_name)

        if action == 'sign' and os.path.exists(csr_path):
            passphrase = request.form.get('code')  # récupération du code saisi
            try:
                signed_cert = sign_csr(
                    csr_path=csr_path,
                    ca_config="../intermediateCA/intermediateCA.cnf",
                    ca_key="../intermediateCA/private/intermediate.key.pem",
                    ca_cert="../intermediateCA/certs/intermediate.crt.pem",
                    output_dir="certs",
                    passphrase=passphrase
                )
                if signed_cert:
                    os.remove(csr_path)
                    message = f"✅ CSR '{csr_name}' signée avec succès."
                    csr_files = [csr for csr in csr_files if csr['name'] != csr_name]
                else:
                    message = f"❌ Erreur lors de la signature de '{csr_name}'. Vérifiez le code."
            except Exception as e:
                message = f"❌ Exception lors de la signature de '{csr_name}' : {str(e)}"
            
        
        
        elif action == 'delete' and os.path.exists(csr_path):
            os.remove(csr_path)
            csr_files = [csr for csr in csr_files if csr['name'] != csr_name]
            message = f"🗑️ CSR '{csr_name}' supprimée."

    return render_template('manage_csrs.html', csrs=csr_files, message=message, user=user)








@app.route('/revoked-signed-certs')
def list_certs():
    user = g.current_user
    if not user:
        return redirect(url_for('login'))

    signed = os.listdir('certs')
    revoked = os.listdir('revoked')
    return render_template('certs_list.html', user=user, signed=signed, revoked=revoked)





@app.route('/sign-csr/<csr_filename>', methods=['POST'])
def sign_csr_route(csr_filename):
    user = g.current_user
    if not user or user["role"] != "ca":
        return redirect(url_for('index'))

    csr_path = os.path.join("csrs", csr_filename)
    action = request.form.get("action")  # 🔥 pour détecter si c'est "sign" ou "delete"

    if action == "sign" and os.path.exists(csr_path):
        signed_cert = sign_csr(
            csr_path=csr_path,
            ca_config="../intermediateCA/intermediateCA.cnf",
            ca_key="../intermediateCA/private/intermediate.key.pem",
            ca_cert="../intermediateCA/certs/intermediate.crt.pem",
            output_dir="certs"
        )

        if signed_cert:
            os.remove(csr_path)  # ✅ supprimer après signature
            return redirect(url_for('pending_csrs', message="CSR signé avec succès."))
        else:
            return redirect(url_for('pending_csrs', message="Échec de la signature du CSR."))

    elif action == "delete" and os.path.exists(csr_path):
        os.remove(csr_path)  # ✅ suppression directe
        return redirect(url_for('pending_csrs', message="CSR supprimé avec succès."))

    return redirect(url_for('pending_csrs', message="Action invalide ou fichier introuvable."))





@app.route('/revoke-cert', methods=['GET', 'POST'])
def revoke_cert():
    user = g.current_user
    if not user:
        return redirect(url_for('login'))

    cert_dir = 'certs'
    revoked_dir = 'revoked'
    certs = os.listdir(cert_dir)
    message = None

    if request.method == 'POST':
        cert_name = request.form['cert']
        cert_path = os.path.join(cert_dir, cert_name)
        revoked_path = os.path.join(revoked_dir, cert_name)

        if os.path.exists(cert_path):
            os.rename(cert_path, revoked_path)
            certs.remove(cert_name)
            message = f"🚫 Certificat '{cert_name}' révoqué avec succès."

    return render_template('revoke_cert.html', user=user, certs=certs, message=message)












@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None

    # Dictionnaire des autorités autorisées (à remplacer plus tard par un fichier ou DB si besoin)
    ca_authorized = {
        "EL-Halhouli Mohamed": "EL-Halhouli Mohamed",

        "Intermediate CA MMSD": "Intermediate CA MMSD",
        "rootCA": "rootCA",
        "ca2": "ca2",
        "ca": "ca",
    }

    if request.method == 'POST':
        role = request.form['role']

        if role == 'client':
            username = request.form['username'].strip()
            if username:
                user = {'id': username, 'role': 'client'}
                g.current_user = user
                session['user'] = user
                return redirect(url_for('index'))
            else:
                error = "Veuillez entrer un nom valide."

        elif role == 'ca':
            ca_name = request.form.get('ca_name')
            code = request.form.get('code', '').strip()
            if ca_name in ca_authorized and ca_authorized[ca_name] == code:
                user = {'id': ca_name, 'role': 'ca'}
                g.current_user = user
                session['user'] = user
                return redirect(url_for('index'))
            else:
                error = "code incorrect."
        else:
            error = "Veuillez sélectionner un rôle valide."

    return render_template('login.html', error=error, ca_list=list(ca_authorized.keys()))








@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
