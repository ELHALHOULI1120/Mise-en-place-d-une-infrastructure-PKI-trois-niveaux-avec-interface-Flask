from flask_login import UserMixin

# Simuler une base de données utilisateur (à améliorer plus tard)
USERS = {
    "client1": {"password": "pass123", "role": "client"},
    "ca1": {"password": "admin123", "role": "ca"}
}

class User(UserMixin):
    def __init__(self, username):
        self.id = username
        self.role = USERS[username]["role"]

    @staticmethod
    def validate(username, password):
        if username in USERS and USERS[username]["password"] == password:
            return User(username)
        return None
