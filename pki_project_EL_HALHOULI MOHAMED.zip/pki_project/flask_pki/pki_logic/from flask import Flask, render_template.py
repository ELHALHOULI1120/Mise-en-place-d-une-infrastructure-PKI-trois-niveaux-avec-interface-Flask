from flask import Flask, render_template, request, redirect, url_for, session, g
import os
import subprocess
from pki_logic.openssl_wrapper import sign_csr
from flask import send_from_directory
from flask import request, redirect, url_for, flash


app = Flask(__name__)
app.secret_key = 'pki_secret'  # Clé de session (à sécuriser en prod)

@app.before_request
def load_user():
    g.current_user = session.get('user', None)


# 📁 Crée automatiquement le dossier csrs/ si nécessaire
os.makedirs("csrs", exist_ok=True)







@app.route('/')
def index():
    if not g.current_user:
        return redirect(url_for('login'))
    return render_template("index.html", user=g.current_user)








@app.route('/generate-csr', methods=['GET', 'POST'])
def generate_csr():
    user = session.get('user')
    if not user or user['role'] != 'client':
        return redirect(url_for('login'))

    if request.method == 'POST':
        cn = request.form['common_name']
        o = request.form['organization']
        ou = request.form['org_unit']
        c = request.form['country']
        email = request.form['email']

        csr_filename = f"csrs/{cn.replace(' ', '_')}.csr"
        key_filename = f"csrs/{cn.replace(' ', '_')}.key"

        # Commande OpenSSL (ligne simple, modifiable)
        subprocess.run([
            "openssl", "req", "-new",
            "-newkey", "rsa:2048",
            "-nodes",
            "-keyout", key_filename,
            "-out", csr_filename,
            "-subj", f"/C={c}/O={o}/OU={ou}/CN={cn}/emailAddress={email}"
        ])

        return render_template("generate_csr.html", user=user, message="CSR générée avec succès.")

    return render_template("generate_csr.html", user=user)









@app.route('/view-certificates')
def view_certificates():
    user = session.get('user')
    if not user or user['role'] != 'client':
        return redirect(url_for('login'))

    certs_dir = 'certs'
    os.makedirs(certs_dir, exist_ok=True)

    all_files = os.listdir(certs_dir)
    user_certs = [f for f in all_files if user['id'] in f]  # filtrage par identifiant

    return render_template('view_certificates.html', user=user, certs=user_certs)

@app.route('/certs/<path:filename>')
def download_cert(filename):
    return send_from_directory('certs', filename, as_attachment=False)








@app.route('/pending-csrs', methods=['GET', 'POST'])
def pending_csrs():
    user = session.get('user')
    if not user or user['role'] != 'ca':
        return redirect(url_for('login'))

    csr_dir = 'csr'
    certs_dir = 'certs'
    os.makedirs(certs_dir, exist_ok=True)

    csrs = os.listdir(csr_dir) if os.path.exists(csr_dir) else []
    message = None

    if request.method == 'POST':
        csr_name = request.form['csr_name']
        action = request.form['action']
        csr_path = os.path.join(csr_dir, csr_name)

        if action == 'sign' and os.path.exists(csr_path):
            # Simulation de signature : on déplace le fichier CSR dans certs/
            signed_cert_path = os.path.join(certs_dir, csr_name.replace('.csr', '.crt'))
            os.rename(csr_path, signed_cert_path)
            message = f"CSR '{csr_name}' signée et déplacée dans 'certs/'."
            csrs.remove(csr_name)

        elif action == 'delete' and os.path.exists(csr_path):
            os.remove(csr_path)
            message = f"CSR '{csr_name}' supprimée."
            csrs.remove(csr_name)

    return render_template('pending_csrs.html', user=user, csrs=csrs, message=message)










@app.route('/sign-delete-csr', methods=['POST'])
def sign_delete_csr():
    user = session.get('user')
    if not user or user['role'] != 'ca':
        return redirect(url_for('login'))

    csr_file = request.form.get('csr_file')
    action = request.form.get('action')
    csr_path = os.path.join('csrs', csr_file)

    if action == 'sign':
        # 📄 Générer un certificat auto-signé (ou appeller un script PKI existant)
        signed_cert_path = os.path.join('certs', csr_file.replace('.csr', '.crt'))
        os.makedirs('certs', exist_ok=True)
        subprocess.run([
            "openssl", "x509", "-req", "-in", csr_path,
            "-signkey", csr_path.replace('.csr', '.key'),
            "-out", signed_cert_path,
            "-days", "365"
        ])
        os.remove(csr_path)  # Supprime la CSR après signature

    elif action == 'delete':
        os.remove(csr_path)

    return redirect(url_for('pending_csrs'))










@app.route('/download-cert/<path:filename>')
def download_cert(filename):
    revoked = request.args.get('revoked', 'false') == 'true'
    directory = 'revoked' if revoked else 'certs'
    return send_from_directory(directory, filename, as_attachment=True)









@app.route('/revoked-signed-certs')
def list_certs():
    user = session.get('user')
    if not user:
        return redirect(url_for('login'))

    signed = os.listdir('certs') if os.path.exists('certs') else []
    revoked = os.listdir('revoked') if os.path.exists('revoked') else []
    return render_template('certs_list.html', user=user, signed=signed, revoked=revoked)










@app.route('/revoke-cert', methods=['GET', 'POST'])
def revoke_cert():
    user = session.get('user')
    if not user:
        return redirect(url_for('login'))

    cert_dir = 'certs'
    revoked_dir = 'revoked'

    certs = os.listdir(cert_dir) if os.path.exists(cert_dir) else []
    message = None

    if request.method == 'POST':
        cert_name = request.form['cert']
        cert_path = os.path.join(cert_dir, cert_name)
        revoked_path = os.path.join(revoked_dir, cert_name)

        if os.path.exists(cert_path):
            os.makedirs(revoked_dir, exist_ok=True)
            os.rename(cert_path, revoked_path)
            message = f"Le certificat '{cert_name}' a été révoqué avec succès."
            certs.remove(cert_name)

    return render_template('revoke_cert.html', user=user, certs=certs, message=message)




@app.route("/sign-csr/<csr_filename>", methods=["POST"])



def sign_csr_route(csr_filename):
    if session.get("user_role") != "CA":
        flash("Accès réservé aux autorités.")
        return redirect(url_for("index"))

    csr_path = os.path.join("csrs", csr_filename)
    signed_cert = sign_csr(
        csr_path=csr_path,
        ca_config="config/intermediateCA.cnf",
        ca_key="private/intermediate.key.pem",
        ca_cert="certs/intermediate.cert.pem",
        output_dir="certs/"
    )

    if signed_cert:
        flash(f"Certificat signé avec succès : {signed_cert}")
    else:
        flash("Erreur lors de la signature.")

    return redirect(url_for("pending_csrs"))



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        role = request.form['role']
        session['user'] = {'id': username, 'role': role}
        return redirect(url_for('index'))
    return render_template("login.html")




@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))




if __name__ == '__main__':
    app.run(debug=True)
