from flask_login import UserMixin
import subprocess
import os
from datetime import datetime





def sign_csr(csr_path, ca_config, ca_key, ca_cert, output_dir, passphrase, days_valid=365):
    basename = os.path.basename(csr_path).split('.')[0]
    signed_cert_path = os.path.join(output_dir, f"{basename}.crt")

    try:
        cmd = [
            "openssl", "ca",
            "-config", ca_config,
            "-in", csr_path,
            "-out", signed_cert_path,
            "-keyfile", ca_key,
            "-cert", ca_cert,
            "-days", str(days_valid),
            "-batch",
            "-passin", f"pass:{passphrase}"  # CECI est la clé
        ]

        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        if result.returncode == 0:
            print("✅ Certificat signé avec succès.")
            return signed_cert_path
        else:
            print("❌ Erreur OpenSSL :", result.stderr)
            return None
    except Exception as e:
        print("❌ Exception lors de la signature :", str(e))
        return None



